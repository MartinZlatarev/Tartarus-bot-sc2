from sc2.ids.unit_typeid import UnitTypeId as UnitID

# TODO: Correct these
PICKUP_RANGE: dict[UnitID, float] = {
    UnitID.MEDIVAC: 5.0,
    UnitID.OVERLORDTRANSPORT: 5.0,
    UnitID.WARPPRISM: 5.0,
}
