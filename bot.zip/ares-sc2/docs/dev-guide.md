# Required reading only if planning to contribute to Ares or understand inner workings

TODO
