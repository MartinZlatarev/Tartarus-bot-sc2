# Behaviors

Use the menu to browse available combat and macro behaviors.
