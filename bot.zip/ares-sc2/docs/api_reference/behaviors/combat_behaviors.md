::: ares.behaviors.combat.combat_maneuver
    options:
        show_root_heading: false
        show_root_toc_entry: false 

::: ares.behaviors.combat.individual.a_move
    options:
        show_root_heading: false
        show_root_toc_entry: false 

::: ares.behaviors.combat.individual.attack_target
    options:
        show_root_heading: false
        show_root_toc_entry: false 

::: ares.behaviors.combat.individual.drop_cargo
    options:
        show_root_heading: false
        show_root_toc_entry: false 

::: ares.behaviors.combat.individual.keep_unit_safe
    options:
        show_root_heading: false
        show_root_toc_entry: false 

::: ares.behaviors.combat.individual.path_unit_to_target
    options:
        show_root_heading: false
        show_root_toc_entry: false 

::: ares.behaviors.combat.individual.pick_up_cargo
    options:
        show_root_heading: false
        show_root_toc_entry: false 

::: ares.behaviors.combat.individual.place_predictive_aoe
    options:
        show_root_heading: false
        show_root_toc_entry: false 

::: ares.behaviors.combat.individual.shoot_target_in_range
    options:
        show_root_heading: false
        show_root_toc_entry: false 

::: ares.behaviors.combat.individual.stutter_unit_back
    options:
        show_root_heading: false
        show_root_toc_entry: false 

::: ares.behaviors.combat.individual.stutter_unit_forward
    options:
        show_root_heading: false
        show_root_toc_entry: false 

::: ares.behaviors.combat.individual.use_ability
    options:
        show_root_heading: false
        show_root_toc_entry: false 

::: ares.behaviors.combat.individual.worker_kite_back
    options:
        show_root_heading: false
        show_root_toc_entry: false 
