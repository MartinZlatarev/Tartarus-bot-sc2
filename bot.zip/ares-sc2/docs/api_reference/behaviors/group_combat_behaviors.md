::: ares.behaviors.combat.group.a_move_group
    options:
        show_root_heading: false
        show_root_toc_entry: false

::: ares.behaviors.combat.group.keep_group_safe
    options:
        show_root_heading: false
        show_root_toc_entry: false

::: ares.behaviors.combat.group.path_group_to_target
    options:
        show_root_heading: false
        show_root_toc_entry: false

::: ares.behaviors.combat.group.stutter_group_back
    options:
        show_root_heading: false
        show_root_toc_entry: false

::: ares.behaviors.combat.group.stutter_group_forward
    options:
        show_root_heading: false
        show_root_toc_entry: false

::: ares.behaviors.combat.group.group_use_ability
    options:
        show_root_heading: false
        show_root_toc_entry: false
